NAVNEET VENDOR MANAGER - Android Studio project

Is folder mein aapki HTML vendor comparison app Android WebView app ke roop mein rakhi gayi hai.
Features: unlimited vendors/items, MRP, weight, brand, purchase rate, quality, lowest rate,
offline local storage, backup export aur backup import.

APK banane ke liye:
1. Computer par Android Studio install karein.
2. Android Studio > Open par click karke is folder ko select karein.
3. Gradle sync complete hone dein (internet chahiye; Android SDK Platform 35 install hona chahiye).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
5. Build complete hone par app/build/outputs/apk/debug/app-debug.apk milegi.
6. APK ko Android phone mein bhejkar install karein. Phone par “Install unknown apps” permission deni pad sakti hai.

App label: NAVNEET VENDOR MANAGER
Application ID: com.navneet.vendormanager

Note: Is project ko yahan APK mein compile/sign nahi kiya gaya, kyunki is environment mein Android SDK/Gradle build tool available nahi hai. Debug APK Android Studio se ban sakti hai. Play Store release ke liye alag signed release build chahiye.
